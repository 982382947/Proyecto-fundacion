
package basedatos;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    private String usuario;
    private String passw;
    
    public Conexion(){
        usuario = "root";
        passw = "";
    }
    
    public Connection conectar(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/fundacion_inventario?useTimezone=true&serverTimezone=UTC", usuario, passw);
            return conexion;
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
